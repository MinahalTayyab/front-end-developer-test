import * as React from 'react';
import {
  View,
  Text,
  Dimensions,
  useWindowDimensions,
  Button,
  SafeAreaView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { TabView, SceneMap } from 'react-native-tab-view';
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';

const Tab = createMaterialTopTabNavigator();

const windowWidth = Dimensions.get('window').width;

import img11 from './11.jpg'
import img12 from './12.jpg'
import img13 from './13.jpg'
import img14 from './14.jpg'
import img15 from './15.jpg'
import img16 from './16.jpg'

const HomeScreen = (props) => (
  <View style={{ flex: 1 }}>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        marginVertical: 4,
      }}>
      {'Unsplash Blog'}
    </Text>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 14,
        color: '#666',
        marginBottom: 4,
      }}>
      {'Stories from the community powering the internet vitals'}
    </Text>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'bold',
        marginLeft: 4,
        marginBottom: 4,
        }}>
      {'Featured'}
    </Text>
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity onPress={() => {
        console.log("nav")
        props.navigation.navigate('Latest')
      }} >
        <Image
          source={img11}
          style={{ width: 500, height: 300 }} />

        <Text style={{ fontWeight: 'Bold', fontSize: '100', color: 'black' }}>
          A Look back on June{' '}
        </Text>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Brennan 12/09/2021
        </Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => {
        console.log("nav")
        props.navigation.navigate('Good')
      }}>
        <Image
          source={img12}
          style={{
            width: 500,
            height: 300,
            justifyContent: 'space-between',
          }}></Image>
        <Text style={{ fontWeight: 'Bold', fontSize: '50', color: 'black' }}>
          Unsplash from Good{' '}
        </Text>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Natalie 20/10/2021
        </Text>
      </TouchableOpacity>
    </View>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'bold',
        marginLeft: 4,
        marginBottom: 4,
      }}>
      {'\n'}
      {'Latest from the team'}
    </Text>
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity onPress={() => {
        console.log("nav")
        props.navigation.navigate('Good')
      }}>
        <Image
          source={img13}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Alex 20/10/2021
        </Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          source={img14}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Begin 20/10/2021
        </Text>
      </TouchableOpacity>
    </View>
    <TouchableOpacity
      style={{
        bottom: 10,
        position: 'absolute',
        alignSelf: 'flex-end',
        width: '100%',
        flexDirection: 'row-reverse',
      }}>
      <Text style={{ fontSize: 18, paddingVertical: 8 }}>{'About '}</Text>
    </TouchableOpacity>
  </View>
);

const CommunityScreen = () => (
  <View style={{ flex: 1 }}>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        marginVertical: 4,
      }}>
      {'Unsplash Blog'}
    </Text>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 14,
        color: '#666',
        marginBottom: 4,
      }}>
      {'Stories from the community powering the internet vitals'}
    </Text>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'bold',
        marginLeft: 4,
        marginBottom: 4,
      }}>
      {'Featured'}
    </Text>
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity>
        <Image
          source={img11}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Brennan 12/09/2021
        </Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          source={img12}
          style={{
            width: 500,
            height: 300,
            justifyContent: 'space-between',
          }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Natalie 20/10/2021
        </Text>
      </TouchableOpacity>
    </View>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'bold',
        marginLeft: 4,
        marginBottom: 4,
      }}>
      {'\n'}
      {'Latest from the team'}
    </Text>
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity>
        <Image
          source={img13}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Alex 20/10/2021
        </Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          source={img14}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Begin 20/10/2021
        </Text>
      </TouchableOpacity>
    </View>
    <TouchableOpacity
      style={{
        bottom: 10,
        position: 'absolute',
        alignSelf: 'flex-end',
        width: '100%',
        flexDirection: 'row-reverse',
      }}>
      <Text style={{ fontSize: 18, paddingVertical: 8 }}>{'About '}</Text>
    </TouchableOpacity>
  </View>
);


const Latest = () => (
  <View style={{ flex: 1 }}>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        marginVertical: 4,
      }}>
      {'A Look Back on June '}
    </Text>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 14,
        color: '#666',
        marginBottom: 4,
      }}>
      {'21 incredible submissions from the past month.'}
    </Text>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'Regular',
        marginLeft: 4,
        marginBottom: 4,
      }}>
    </Text>
     <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity>
          <Image
          source={img11}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Brennan 12/09/2021
        </Text>
      </TouchableOpacity>      
    </View>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'Regular',
        marginLeft: 4,
        marginBottom: 4,
      }}>
      {'\n'}
      {'In June, 127,463 images were submitted to the library. Here are 21 images that caught the eye of the Unsplash submissions team this past month — from a protest of the U.S Supreme Court’s decision to overturn Roe v. Wade to roller skating during a Pride parade.'}
    </Text>
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity>
        <Image
          source={img15}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          “I took this at the Trans March in San Francisco the day the Supreme Court overturned Roe v. Wade. After the pain of seeing the news that morning, it was soothing to be a part of a crowd of people marching to demand that their rights be respected.” — Patrick Perkins 🇺🇸
        </Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          source={img14}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Begin 20/10/2021
        </Text>
      </TouchableOpacity>
    </View>
    <TouchableOpacity
      style={{
        bottom: 10,
        position: 'absolute',
        alignSelf: 'flex-end',
        width: '100%',
        flexDirection: 'row-reverse',
      }}>
     </TouchableOpacity>
  </View>
);

const Good = () => (
  <View style={{ flex: 1 }}>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        marginVertical: 4,
      }}>
      {'Unsplash For Good '}
    </Text>
    <Text
      style={{
        textAlign: 'center',
        fontSize: 14,
        color: '#666',
        marginBottom: 4,
      }}>
      {'Making a global impact through visual representation.'}
    </Text>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'Regular',
        marginLeft: 4,
        marginBottom: 4,
      }}>
    </Text>
     <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity>
          <Image
          source={img12}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Brennan 12/09/2021
        </Text>
      </TouchableOpacity>      
    </View>
    <Text
      style={{
        fontSize: 18,
        fontWeight: 'Regular',
        marginLeft: 4,
        marginBottom: 4,
      }}>
      {'\n'}
      {'In June, 127,463 images were submitted to the library. Here are 21 images that caught the eye of the Unsplash submissions team this past month — from a protest of the U.S Supreme Court’s decision to overturn Roe v. Wade to roller skating during a Pride parade.'}
    </Text>
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity>
        <Image
          source={img15}
          style={{ width: 500, height: 300 }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          “I took this at the Trans March in San Francisco the day the Supreme Court overturned Roe v. Wade. After the pain of seeing the news that morning, it was soothing to be a part of a crowd of people marching to demand that their rights be respected.” — Patrick Perkins 🇺🇸
        </Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          source={img16}
          style={{ width: 500, height: 300, position:'absolute' }}></Image>
        <Text
          style={{ fontWeight: 'Regular', fontSize: '100', color: 'black' }}>
          Begin 20/10/2021
        </Text>
      </TouchableOpacity>
    </View>
    <TouchableOpacity
      style={{
        bottom: 10,
        position: 'absolute',
        alignSelf: 'flex-end',
        width: '100%',
        flexDirection: 'row-reverse',
      }}>
     </TouchableOpacity>
  </View>
);


export default function TabViewExample() {
  const layout = useWindowDimensions();

  const [index, setIndex] = React.useState(0);

  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Community" component={CommunityScreen} />
        <Tab.Screen name="Latest" component={Latest} />
        <Tab.Screen name="Good" component={Good} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

